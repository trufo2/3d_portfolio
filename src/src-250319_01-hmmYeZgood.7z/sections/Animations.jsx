const Animations = () => {
  return (
    <section id="animations" className="hero-section hero-section-a">
      <div className="hero-section-b">
        <p className="hero-section-c">Animations</p>
        <p className="hero_tag hero-section-d">section "animations"</p>
      </div>
    </section>
  );
};

export default Animations;