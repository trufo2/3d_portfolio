const Art = () => {
  return (
    <section id="art" className="hero-section hero-section-a">
      <div className="hero-section-b">
        <p className="hero-section-c">Art</p>
        <p className="hero_tag hero-section-d">section"art"</p>
      </div>
    </section>
  );
};

export default Art;