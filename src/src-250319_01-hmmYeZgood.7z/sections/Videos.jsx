const Videos = () => {
  return (
    <section id="videos" className="hero-section hero-section-a">
      <div className="hero-section-b">
        <p className="hero-section-c">Vidéos</p>
        <p className="hero_tag hero-section-d">section "vidéos"</p>
      </div>
    </section>
  );
};

export default Videos;