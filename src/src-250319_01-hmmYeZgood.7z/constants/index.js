export const navLinks = [
    {
        id: 1,
        name: 'Sites',
        href: '/sites',
    },
    {
        id: 2,
        name: 'Animations',
        href: '/animations',
    },
    {
        id: 3,
        name: 'Vidéos',
        href: '/videos',
    },
    {
        id: 4,
        name: 'Art',
        href: '/art',
    },
];